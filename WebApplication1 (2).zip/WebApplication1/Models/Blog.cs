﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace WebApplication1.Models
{
    [BsonIgnoreExtraElements]
    public class Blog
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }= String.Empty;

        [BsonElement("title")]
        public string Title { get; set; }=String.Empty;

        [BsonElement("body")]
        public string Body { get; set; } = String.Empty;

        [BsonElement("author")]
        public string Author { get; set; } =String.Empty;

    }
}
