﻿namespace WebApplication1.Models
{
    public class BlogStoreDatabaseSettings: IBlogStoreDatabaseSettings
    {
        public string BlogCollectionName { get; set; } =String.Empty;
        public string ConnectionString { get; set; } =String.Empty;
        public string DatabaseName { get; set; }= String.Empty;
    }
}
