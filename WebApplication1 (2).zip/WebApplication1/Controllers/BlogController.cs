﻿using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata;
using WebApplication1.Models;
using WebApplication1.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BlogController : ControllerBase
    {
        private readonly IBlogService blogService;

        public BlogController(IBlogService blogService)
        {
            this.blogService = blogService;
        }
        // GET: api/<BlogController>
        [HttpGet]
        public ActionResult<List<Blog>>Get()
        {
            return blogService.Get();
        }

        // GET api/<BlogController>/5
        [HttpGet("{id}")]
        public ActionResult<Blog> Get(string id)
        {
            var blog = blogService.Get(id);
            
            if(blog == null)
            {
                return NotFound($"Blog with Id={id} not found");
            }

            Console.WriteLine(id);
            return blog;
        }

        // POST api/<BlogController>
        [HttpPost]
        public ActionResult<Blog> Post([FromBody] Blog blog)
        {
            blogService.Create(blog);
       
            return CreatedAtAction(nameof(Get), new {id=blog.Id},blog);

        }

        // PUT api/<BlogController>/5
        [HttpPut("{id}")]
        public ActionResult Put(string id, [FromBody] Blog blog)
        {
            var existingBlog=blogService.Get(id);

            if(existingBlog == null)
            {
                return NotFound($"Blog with Id={id} not found");
            }
            blogService.Update(id, blog);

            return NoContent();
        }

        // DELETE api/<BlogController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(string id)
        {
            var blog = blogService.Get(id);

            if (blog == null)
            {
                return NotFound($"Blog with Id={id} not found");
            }
            blogService.Remove(blog.Id);
            return Ok($"Student with Id={id} deleted");
        }
    }
}
