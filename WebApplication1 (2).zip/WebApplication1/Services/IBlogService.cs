﻿using WebApplication1.Models;

namespace WebApplication1.Services
{
    public interface IBlogService
    {
        List<Blog> Get();
        Blog Get(string id);
        Blog Create(Blog blog);
        void Update(string id,Blog blog);
        void Remove(string id);
    }
}
