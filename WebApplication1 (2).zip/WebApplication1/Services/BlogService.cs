﻿using WebApplication1.Models;
using MongoDB.Driver;

namespace WebApplication1.Services
{
    public class BlogService : IBlogService
    {
        private readonly IMongoCollection<Blog> _blogs;
        
        public BlogService(IBlogStoreDatabaseSettings settings,IMongoClient mongoClient)
        {
            var database=mongoClient.GetDatabase(settings.DatabaseName);
            _blogs = database.GetCollection<Blog>(settings.BlogCollectionName);
        }
        public Blog Create(Blog blog)
        {
            _blogs.InsertOne(blog);
            return blog;
        }

        public List<Blog> Get()
        {
            return _blogs.Find(blog=>true).ToList();
        }

        public Blog Get(string id)
        {
            return _blogs.Find(blog=>blog.Id==id).FirstOrDefault();
        }

        public void Remove(string id)
        {
            _blogs.DeleteOne(blog=>blog.Id==id);
        }

        public void Update(string id, Blog blog)
        {
            _blogs.ReplaceOne(blog => blog.Id == id,blog);
        }
    }
}
